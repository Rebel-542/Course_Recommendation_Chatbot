import random
import json
import pickle
import numpy as np
import nltk
import streamlit as st

from nltk.stem import WordNetLemmatizer
from tensorflow.keras.models import load_model

# Create lemmatizer
lemmatizer = WordNetLemmatizer()

# Load the trained model
model = load_model("chatbot_model.keras")

# Load words and classes
words = pickle.load(open("words.pkl", "rb"))
classes = pickle.load(open("classes.pkl", "rb"))

# Load intents
with open("intents.json") as file:
    intents = json.load(file)

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [
        lemmatizer.lemmatize(word.lower())
        for word in sentence_words
    ]
    return sentence_words

def bag_of_words(sentence):
    sentence_words = clean_up_sentence(sentence)

    bag = [0] * len(words)

    for sw in sentence_words:
        for i, word in enumerate(words):
            if word == sw:
                bag[i] = 1

    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence)

    prediction = model.predict(np.array([bow]), verbose=0)[0]

    ERROR_THRESHOLD = 0.70

    results = [
        (i, probability)
        for i, probability in enumerate(prediction)
        if probability > ERROR_THRESHOLD
    ]

    results.sort(key=lambda x: x[1], reverse=True)

    intents_list = []

    for result in results:
        intents_list.append({
            "intent": classes[result[0]],
            "probability": str(result[1])
        })

    return intents_list

def get_response(intents_list, intents_json):

    if len(intents_list) == 0:
        return "Sorry! I couldn't understand. Try words like AI, coding, designing, security, business, data, cloud, etc."

    tag = intents_list[0]["intent"]

    for intent in intents_json["intents"]:
        if intent["tag"] == tag:
            return random.choice(intent["responses"])

st.title("🎓 Course Recommendation Chatbot")

st.write("Tell me your interests, and I'll recommend a suitable course.")

# Sidebar
st.sidebar.title("About")
st.sidebar.write(
    """
    This chatbot recommends suitable courses
    based on the user's interests using
    Natural Language Processing (NLP)
    and Deep Learning.
    """
)

user_input = st.text_input("Enter your message:")

if st.button("Recommend Course"):

    if user_input.strip() == "":
        st.warning("Please enter your interests.")

    else:
        predicted_intents = predict_class(user_input)

        response = get_response(predicted_intents, intents)

        st.success(response)

st.markdown("---")
st.caption("Developed by Muaaz Ali | Course Recommendation Chatbot")